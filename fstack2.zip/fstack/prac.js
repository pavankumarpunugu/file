function eval()
{
	var sq=document.getElementById("101").value;
	var cub=document.getElementById("102").value;
	var sqr=sq*sq;
	var cubr=cub*cub*cub;
	document.write(sqr+" , "+cubr);
	

}





