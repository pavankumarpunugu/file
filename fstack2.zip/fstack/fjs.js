function message()
{
alert("this is pop message");
}
var x=5;
var y=9;
if(x==y);
{
document.write("x is equals to y");
}
document.write("<br>");
for(i=0;i<5;i++)
{
	document.write( "the number is "+ i);
	document.write("<br>");
	
}
document.write(x);


