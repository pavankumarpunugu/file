let allchoices=document.querySelectorAll(".choices");

let data1=document.getElementById("rock");
let data1val=data1.innerText;
let data2=document.getElementById("paper");
let data2val=data2.innerText;
let data3=document.getElementById("scissor");
let data3val=data3.innerText;

let usr1=data2.addEventListener("click",()=>{console.log("user choice was paper ")});
let usr2=data1.addEventListener("click",()=>{console.log("user choice  was rock" )});
let usr3=data3.addEventListener("click",()=>{console.log("user choice was scissor")});
let usrar=[usr1,usr2,usr3];

let vals=[data1,data2,data3];
let rand=Math.floor(Math.random()*3);
let zero;
let one;
let two;
if(rand===0){
console.log(data1val," paper was compter choice");
}
else if(rand===1){
console.log(data2val," rock was compter choice");
}
else if(rand===2){
console.log(data3val," scissor was compter choice" );
}
for(usr of usrar){
if(usr[0]===rand){
console.log("draw");}
else if(usr[1]===rand){
console.log("draw");}
else if(usr[2]===rand){
console.log("draw");}

}



/*allchoices.forEach((choice)=>{

choice.addEventListener("click",()=>{
if(choice===data2){

console.log("paper is clicked");
}
});

});*/




