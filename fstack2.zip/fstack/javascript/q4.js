/*let fullName=prompt("Enter your FullName");
let len=fullName.length;
console.log(`your Username was : @${fullName}${len}`);*/

let sent="hello bro how are you";
let wcount=sent.split(" ");
let words=wcount.length;
console.log(words);
