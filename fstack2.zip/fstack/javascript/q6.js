/*let vowels=["a","e","i","o","u"];
let sum=0;
function find(key){
for(let i=0;i<key.length;i++){
	for(let j=0;j<vowels.length;j++){
		if (key[i]==vowels[j]){
			sum=sum+1;
			}
		}
	

}
return sum;	

}
let result=find("apnacollege");
console.log(`the number of vowels is ${result}`);*/

/*const count=(key)=>{
let sum=0;
for(const char of key){
if(char==="a"|| char==="e" || char==="i"|| char==="o" || char==="u"){
sum++;}
}
return sum;
}
console.log(count("apple"));*/

/* //this is foreach array which is used for performing tasks in an array and it doesnot returns new array like map
let nums=[1,2,3,4,5,6,7,8,9];
nums.forEach((vals)=>{
console.log(vals*vals);

})
*/
/* // this is map array use to perform tasks in an array and it always returns new arary like this
let nums=[2,8,26,18,4];
let result=nums.map((vals)=>{
console.log(vals*vals);

})*/

/*let func=(vals)=>{
console.log(vals*vals);
}
let nums=[2,8,26,18,4,99,15];
let result=nums.map((func));*/

//making a new array from existing array using map
/*let nums=[2,5,6,7,9];
let sqarr=nums.map((val)=>{
return val+2;
});
console.log(sqarr);*/

// this is for filter example

/*let nums=[2,4,7,18,13,17,26];
let result=nums.filter((vals)=>{
return vals%2==0;
});
console.log(result);*/

//this is example for reduce in js

let nums=[2,29,6,101,16,9];
let newarr=nums.reduce((res,cur)=>{
//return res+cur;
if (res<cur){
res=cur;
}
return res;
});
console.log(newarr);



