let bt1=document.querySelector("#bt1");
let white;
let dark;
let curr=document.querySelector("body");


bt1.addEventListener("click",()=>{
let mode=curr.style.backgroundColor;
if(mode == "black"){

white=document.body.style.backgroundColor="white";
}
else{
dark=document.body.style.backgroundColor="black";
}
}
);

