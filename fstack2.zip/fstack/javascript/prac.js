/*function greet(name,func){
console.log("hello",name);
func(25);

}
function details(age){

console.log("age is",age);
}

greet("pavan",details);*/
/*function fetch(getData){
console.log("The data is Fetching...")
setTimeout(()=>{
getData("hello");
},2000);

}
function data(data1){
console.log("this is data",data1);
}
fetch(data);*/
/*let promise=new Promise((resolve,reject)=>{
let sucess=true;
 setTimeout(()=>{
 if(sucess){
 resolve("data fetched sucssfully");}
 else{
 reject("failed to fetch");}
 },2000);


});*/

async function order(){
let promise=new Promise((resolve,reject)=>{
console.log("order placed");
resolve=false;
setTimeout(()=>{
if(resolve){console.log("food is ready")}
else{console.log("food is cancelled")};

},5000);


});
let result=await promise;
};

order();


