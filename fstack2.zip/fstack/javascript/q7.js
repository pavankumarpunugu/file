/*let marks=[87,93,64,99,86,96,95,91];
let result=marks.filter((vals)=>{
return vals>90;
});
console.log(result);*/

let n=prompt("enter the numbers in array");
let arr=[];
for(i=0;i<n;i++){
	
	arr.push(i+1);
}	
//console.log(arr);
/* this is used for adding in arary using map
let result=arr.reduce((res,cur)=>{
return res+cur;
});
console.log(result);*/

let result2=arr.reduce((ress,curr)=>{

return ress*curr;
});
console.log(result2);
