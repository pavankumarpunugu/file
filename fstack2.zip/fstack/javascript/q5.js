//let marks=[85,97,44,37,76,60];
//let len=marks.length;
//let sum=0;
/*for(let i=0;i<len;i++){
	sum=sum+marks[i];
}*/
//for(let val of marks){
//sum+=val;
//}
//let avg=sum/len;
//console.log(avg);

/*let intial=[250,645,300,900,50];
let offer=[];
let result;
let endr;*/
/*for(let val of intial)
{
	result=10/100*val;
	endr=val-result;
	offer.push(endr);
	
}
console.log(`the prices after giving 10% offer ${offer}`);*/
/*for(let i=0;i<intial.length;i++){
result=10/100*intial[i];
endr=intial[i]-result;
console.log(`the items after applying offer is follows:${endr}`)
}*/

let companies=["Bloomberg","Microsoft","Uber","Google","IBM","Netflix"];
/*let del=companies.shift();
console.log(del);
let added=companies.splice(2,1,"Ola");
console.log(added);*/
companies.push("Amazon");
console.log(companies);

