let para=document.querySelector("#para");
let btn=document.querySelector("#btn");
let num=2;
async function getData(){
let response=await fetch("https://cat-fact.herokuapp.com/facts/");
let data=await response.json();
let result=btn.addEventListener("click",()=>{

result=data[3].text;
document.write(result);
});

};
getData();


