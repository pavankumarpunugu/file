let data="personal info";
class user{

constructor(name,gmail){
this.name=name;
this.gmail=gmail;
}

viewData(){
console.log(`name is ${this.name} and email was ${this.gmail}`);

}


}

class Admin extends user{
constructor(name,gmail){

super(name,gmail);
}

editdata(){
data="data is edited";

}

}




let obj=new user("pavan","@gmail.com");
let obj2=new Admin("rahul","@ghhs");
obj2.editdata();


