/*
for(let i=0;i<=100;i++){
if(i%2==0){
console.log(i);
}
}*/
/*Guess A Number
let gameNum=25;
let useNum=prompt("Guess a Number");
while(useNum != gameNum){
	useNum=prompt("Wrong,Guess Again!");	
}
console.log("you win");
*/
/*
let i=1;
while(i<=20)
{
console.log(i);
i++;
}*/
/*let num=5;
for(let i=1;i<=10;i++){
console.log(num*i);
}*/
/*
let num=6;
let i;
let result=1;
for(i=num;i>=1;i--)
{
	result=result*(i);
	
}
console.log(result);*/
/*let num="1234999";
let count=0;
for(i in num)
{
	count=count+1;
}
console.log(count);*/
let s1="hello";
let rev="";
for(let i=4;i>=0;i--)
{
	console.log(s1[i]);
}
//console.log(rev);



