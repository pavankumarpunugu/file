/*let newbtn=document.createElement("button");
newbtn.innerText="click me";
document.body.append(newbtn);
newbtn.style.backgroundColor="red";
newbtn.style.color="white";*/

let a=document.querySelector("p");
console.log(a.getAttribute("class"));
//a.classList.add("new");
a.setAttribute("class","new");
console.log(a);
