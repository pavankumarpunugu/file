/*let div=document.getElementsByClassName("box1");
num=1;
for(divs of div){
divs.innerText=`this unique value ${num}` ;
num++;
}*//*
let div=document.getElementById("fr");
console.log(div.outerHTML);*/

/*let ans=document.getElementById("heading");
ans.innerText="updatedhtml";*/
document.getElementById("title").innerText="Welcome to javascript Dom";
let result=document.getElementsByClassName("info");
for(let val of result){
console.log(val.innerText);
}
let hm=document.getElementById("inputBox");
console.log(hm.outerHTML);

let r1=document.getElementsByClassName("item");
for(let vals of r1){
console.log(vals.innerText);
}

