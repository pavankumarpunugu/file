/*let num=prompt("Enter number");
if(num%5===0){
console.log(num ,"is divisible by 5");
}
else{
console.log(num ,"is not divisible by 5");
}*/
let grade;
let score=prompt("please enter your marks");

if(score>=90 && score<=100){
grade="A";
}
else if(score>=80 && score<=89){
grade="B";
}
else if(score>=70 && score<=79){
grade="C";
}
else if(score>=60 && score<=69){
grade="D";
}
else if(score>=50 && score<=59){
grade="E";
}
else if(score>=0 && score<=48){
grade="F";
}
else{
console.log("please enter correct marks");}

console.log("According to your score grade was:",grade);

