let amount=document.querySelectorAll(".amount input");
console.log(amount[0].value);

let selectf=document.getElementById("x");
console.log(selectf.value);

let selectf2=document.getElementById("y");
console.log(selectf2.value);

let r1=selectf.value;
let r2=selectf2.value;
let ram=amount[0].value;
let final=document.getElementById("msg");
document.getElementById("btn").addEventListener("click",async (evn)=>{

let url=await fetch(`https://api.exchangerate.host/convert?/from=${r1}&to=${r2}&amount=${ram}`);
let data=await url.json();
console.log(data);
final.innerText=(data);
}

);







