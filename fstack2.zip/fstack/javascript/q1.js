/*const product={
name:"Parker Joter",
rating:4,
isDeal:true,
offer:5,
price:270

};
product["price"]=product["price"]+100;
console.log(product["rating"]);
console.log(product["price"]);
console.log(product["name"]);*/
const profile={
userName:"@anonymous22.12",
isFollow:true,
followers:123,
following:456

};


